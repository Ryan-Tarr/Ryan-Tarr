function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0,150,230);
  fill(250,200,150)
  rect(000,290,400);
  fill(230,100,0);
  triangle(300,100,250,150,300,200);
  fill(250,150,0);
  ellipse(225,150,100);
  fill(230,150,0);
  triangle(250,180,220,160,250,155);
  fill(225);
  ellipse(200,135,30);
  fill(0);
  ellipse(198,137,15);
}
